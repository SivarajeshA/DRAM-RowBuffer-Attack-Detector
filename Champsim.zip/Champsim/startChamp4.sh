# Before running this, make sure that your 'pin' tool path is set and $RA path is set
# $1 gives 1st argument
if [ "$1" = "--help" ]
then
    echo -e "Syntax:\n$ bash getTrace.sh programName[w/o_extension] 1[to zip and copy file]"
    echo "Remember to set pin path and RA path in .profile"
    exit
fi
source ~/.profile
rm -f $1.trace $2.trace $3.trace $4.trace
rm -f $1.trace.gz $2.trace.gz $3.trace.gz $4.trace.gz
echo "***Old Files removed***"
echo " "
gcc $1.c -O0 -o $1 -g
#g++ $2.cpp -O0 -o $1 -g
#g++ $3.cpp -O0 -o $1 -g
#g++ $4.cpp -O0 -o $1 -g
echo " "
echo "***Binaries created***"
echo " "
pin -t obj-intel64/champsim_tracer.so -s 100000 -t 2000000 -o $1.trace -- ./$1
echo " "
echo $1" trace created "
echo " "
pin -t obj-intel64/champsim_tracer.so -s 100000 -t 2000000 -o $2.trace -- ./$2
echo " "
echo $2" trace created "
echo " "
pin -t obj-intel64/champsim_tracer.so -s 100000 -t 2000000 -o $3.trace -- ./$3
echo " "
echo $3" trace created "
echo " "
pin -t obj-intel64/champsim_tracer.so -s 100000 -t 2000000 -o $4.trace -- ./$4
echo " "
echo $4" trace created "
echo " "

#if [ "$5" = "1" ]
#then
    gzip $1.trace
    gzip $2.trace
    gzip $3.trace
    gzip $4.trace
    mv $1.trace.gz /home/sivaraj/Music/ChampSim-Inclusive-master/tracer
    mv $2.trace.gz /home/sivaraj/Music/ChampSim-Inclusive-master/tracer
    mv $3.trace.gz /home/sivaraj/Music/ChampSim-Inclusive-master/tracer
    mv $4.trace.gz /home/sivaraj/Music/ChampSim-Inclusive-master/tracer
    echo " "
    echo "***Traces moved to /tracer***"
    echo " "
#fi
cd $RA 
bash run_4core.sh bimodal-no-no-no-lru-4core 0 1 0 $1.trace.gz $2.trace.gz $3.trace.gz $4.trace.gz
# bash run_4core.sh bimodal-no-no-no-lru-4core 0 1 0 sender.trace.gz test2.trace.gz test.trace.gz receiver.trace.gz
# bash run_4core.sh bimodal-no-no-no-lru-4core 0 1 0 set_sender.trace.gz test2.trace.gz test.trace.gz set_receiver.trace.gz
bash run_4core.sh bimodal-no-no-no-lru-4core 0 1 0 set_sender.trace.gz example1.trace.gz example2.trace.gz set_receiver.trace.gz

echo " "
echo "Champsim run finished"
echo " "

# Total instructions w/o anything in main = 115502
# Total instructions with something main = 1476766
# 
#To run:  bash getTrace.sh test 1
